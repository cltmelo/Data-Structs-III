# Universisdade de São Paulo - São Carlos
## Organização e Arquitetura de Computadores
  - Ambiente colaborativo de desenvolvimento às atividades da disciplina **SCC0607 - Estrutura de Dados III**.
  - Integrantes do grupo:
      - Lucas Corlete Alves de Melo - nusp: 13676461
      - Jean Carlos Pereira Cassiano - nusp: 13864008
  - Professora:
      - Cristina Dutra de Aguiar

###Observações:
	No diretório "/ED3/13676461" já encontram-se todos os arquivos .c e .h do respectivo Trabalho Prático, os casos testes e os arquivos de dados.
