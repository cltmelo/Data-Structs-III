#ifndef REGISTROS_H
#define REGISTROS_H

// Declaração da função de soma
int somar(int a, int b);

#endif