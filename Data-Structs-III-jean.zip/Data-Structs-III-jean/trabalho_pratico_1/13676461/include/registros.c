#include "registros.h"

// Implementação da função somar
int somar(int a, int b) {
    return a + b;
}
